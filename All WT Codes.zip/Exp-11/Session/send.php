<?php
            
    if (isset($_POST['login']) && !empty($_POST['username']) && !empty($_POST['password'])) {
				
        if ($_POST['username'] == 'Pranav' && $_POST['password'] == 'Pass@123') {
            $_SESSION['valid'] = true;
            $_SESSION['timeout'] = time();
            $_SESSION['username'] = 'Pranav';      
            echo 'You have entered valid use name and password ! <br>';
            echo "Your Session details are: <br>"; 
            echo "Session username: ".$_POST['username']."<br>";
            echo "Session Password: ".$_POST['password']."<br>";
            echo "Session Login Time: ".$_SESSION['timeout']."<br>";
            echo " Click here to clean <a href = 'logout.php' tite = 'Logout'>Session";

        }
    }
    else {
        echo 'Wrong username or password';
    }
    
?>