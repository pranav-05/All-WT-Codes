<?php
    $uid = ($_POST['uid']);
    $uname = ($_POST['uname']);
    $umail = ($_POST['umail']);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mydb";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if($conn->connect_error)
    {
        die ("Connection error !" .$conn->connect_error);
    }else{

        echo "Connection Successful !!!";
    }
    $sql = "UPDATE student SET name='$uname', email='$umail' WHERE id='$uid'";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
      } else {
        echo "Error updating record: " . $conn->error;
      }
      
      $conn->close();

?>